#include "histogram.h"
#include "names.h"

#include <future>
#include <thread>
#include <vector>
#include <algorithm>

void get_histogram(const std::vector<word_t>& words, histogram_t& histogram, int num_threads)
{
    // put your code here
}
